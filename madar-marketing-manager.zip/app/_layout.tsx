import "@/global.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack, router, useSegments } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import "react-native-reanimated";
import { I18nManager, Platform, BackHandler } from "react-native";
import "@/lib/_core/nativewind-pressable";
import { ThemeProvider } from "@/lib/theme-provider";
import { AppProvider, useApp } from "@/lib/app-context";
import { AppCustomizationProvider } from "@/lib/app-customization-context";
import { LoadingScreen } from "@/components/loading-screen";
import { AppAlertProvider } from "@/components/app-alert-provider";
import { ErrorBoundary } from "@/components/error-boundary";
import { OperationProgressOverlay } from "@/components/operation-progress-overlay";
import {
  SafeAreaFrameContext,
  SafeAreaInsetsContext,
  SafeAreaProvider,
  initialWindowMetrics,
} from "react-native-safe-area-context";
import type { EdgeInsets, Metrics, Rect } from "react-native-safe-area-context";

import { trpc, createTRPCClient } from "@/lib/trpc";
import { initManusRuntime, subscribeSafeAreaInsets } from "@/lib/_core/manus-runtime";
import { AUTH_CHECK_TIMEOUT_MS, shouldShowLoading } from "@/lib/auth-loading";

// التخطيط البصري LTR في الهاتف والمعاينة، مع إبقاء النصوص العربية بمحاذاتها المحددة داخل مكوّناتها.
I18nManager.allowRTL(false);
I18nManager.forceRTL(false);

if (Platform.OS !== "web") {
  SplashScreen.setOptions({ duration: 280, fade: true });
}

const DEFAULT_WEB_INSETS: EdgeInsets = { top: 0, right: 0, bottom: 0, left: 0 };
const DEFAULT_WEB_FRAME: Rect = { x: 0, y: 0, width: 0, height: 0 };

export const unstable_settings = {
  anchor: "(tabs)",
};

function AuthGuard({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useApp();
  const [authCheckTimedOut, setAuthCheckTimedOut] = useState(false);
  const segments = useSegments();
  const redirectInFlight = useRef(false);

  useEffect(() => {
    const timer = setTimeout(() => setAuthCheckTimedOut(true), AUTH_CHECK_TIMEOUT_MS + 500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      redirectInFlight.current = false;
      return;
    }

    const isLoginRoute = segments[0] === "login";
    if ((!isLoading || authCheckTimedOut) && !isLoginRoute && !redirectInFlight.current) {
      redirectInFlight.current = true;
      router.replace("/login");
    }
  }, [authCheckTimedOut, isAuthenticated, isLoading, segments]);

  const showLoading = shouldShowLoading(Platform.OS, isLoading, authCheckTimedOut);

  return (
    <>
      <LoadingScreen visible={showLoading} message="جاري تحميل التطبيق..." />
      {children}
    </>
  );
}

export default function RootLayout() {
  const initialInsets = initialWindowMetrics?.insets ?? DEFAULT_WEB_INSETS;
  const initialFrame = initialWindowMetrics?.frame ?? DEFAULT_WEB_FRAME;

  const [insets, setInsets] = useState<EdgeInsets>(initialInsets);
  const [frame, setFrame] = useState<Rect>(initialFrame);

  // Initialize Manus runtime for cookie injection from parent container
  useEffect(() => {
    initManusRuntime();
  }, []);

  const handleSafeAreaUpdate = useCallback((metrics: Metrics) => {
    setInsets(metrics.insets);
    setFrame(metrics.frame);
  }, []);

  useEffect(() => {
    if (Platform.OS !== "web") return;
    const unsubscribe = subscribeSafeAreaInsets(handleSafeAreaUpdate);
    return () => unsubscribe();
  }, [handleSafeAreaUpdate]);

  // دعم زر رجوع الهاتف
  useEffect(() => {
    if (Platform.OS === "web") return;
    const backHandler = BackHandler.addEventListener("hardwareBackPress", () => {
      // السماح للنظام بمعالجة الرجوع
      return false;
    });
    return () => backHandler.remove();
  }, []);

  // Create clients once and reuse them
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            // Disable automatic refetching on window focus for mobile
            refetchOnWindowFocus: false,
            // Retry failed requests once
            retry: 1,
          },
        },
      }),
  );
  const [trpcClient] = useState(() => createTRPCClient());

  // Ensure minimum 8px padding for top and bottom on mobile
  const providerInitialMetrics = useMemo(() => {
    const metrics = initialWindowMetrics ?? { insets: initialInsets, frame: initialFrame };
    return {
      ...metrics,
      insets: {
        ...metrics.insets,
        top: Math.max(metrics.insets.top, 16),
        bottom: Math.max(metrics.insets.bottom, 12),
      },
    };
  }, [initialInsets, initialFrame]);

  const content = (
    <GestureHandlerRootView style={{ flex: 1, direction: "ltr" }}>
      <trpc.Provider client={trpcClient} queryClient={queryClient}>
        <QueryClientProvider client={queryClient}>
          {/* Default to hiding native headers so raw route segments don't appear (e.g. "(tabs)", "products/[id]"). */}
          {/* If a screen needs the native header, explicitly enable it and set a human title via Stack.Screen options. */}
          {/* in order for ios apps tab switching to work properly, use presentation: "fullScreenModal" for login page, whenever you decide to use presentation: "modal*/}
          <AppProvider>
            <AppCustomizationProvider>
              <ErrorBoundary>
                <AppAlertProvider>
                  <AuthGuard>
                    <Stack screenOptions={{ 
                      headerShown: false,
                    }}>
                      <Stack.Screen name="(tabs)" />
                      <Stack.Screen name="external-analytics" />
                      <Stack.Screen name="goal-details" />
                      <Stack.Screen name="login" />
                      <Stack.Screen name="oauth/callback" />
                    </Stack>
                    <OperationProgressOverlay />
                  </AuthGuard>
                </AppAlertProvider>
              </ErrorBoundary>
            </AppCustomizationProvider>
          </AppProvider>
          <StatusBar style="auto" />
        </QueryClientProvider>
      </trpc.Provider>
    </GestureHandlerRootView>
  );

  const shouldOverrideSafeArea = Platform.OS === "web";

  if (shouldOverrideSafeArea) {
    return (
      <ThemeProvider>
        <SafeAreaProvider initialMetrics={providerInitialMetrics}>
          <SafeAreaFrameContext.Provider value={frame}>
            <SafeAreaInsetsContext.Provider value={insets}>
              {content}
            </SafeAreaInsetsContext.Provider>
          </SafeAreaFrameContext.Provider>
        </SafeAreaProvider>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider>
      <SafeAreaProvider initialMetrics={providerInitialMetrics}>{content}</SafeAreaProvider>
    </ThemeProvider>
  );
}
