export type WarehouseMovementUnit = "package" | "piece";

export interface WarehousePackageQuantity {
  currentQuantity: number;
  piecesPerPackage?: number;
  packageCount?: number;
}

function positiveWholeNumber(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : fallback;
}

function positiveDecimal(value: unknown, fallback: number): number {
  return parsePositiveWarehouseDecimal(value) ?? fallback;
}

/** تقبل الإدخال المحلي بالفاصلة أو النقطة وتعيد قيمة موجبة فقط. */
export function parsePositiveWarehouseDecimal(value: unknown): number | undefined {
  const normalized = typeof value === "string" ? value.trim().replace(",", ".") : value;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
}

function formatDecimal(value: number): string {
  return Number.isInteger(value) ? String(value) : String(Math.round(value * 1000) / 1000);
}

/** تعيد عدد قطع الطرد مع توافق تلقائي للمواد القديمة المخزنة بالقطعة. */
export function getPiecesPerPackage(item: Pick<WarehousePackageQuantity, "piecesPerPackage">): number {
  return positiveWholeNumber(item.piecesPerPackage, 1);
}

/** تحتفظ currentQuantity دائماً بإجمالي القطع كي لا تتعطل السجلات القديمة. */
export function calculatePackagePieces(packageCount: unknown, piecesPerPackage: unknown): number {
  return positiveDecimal(packageCount, 0) * positiveWholeNumber(piecesPerPackage, 0);
}

export function calculateMovementPieces(quantity: unknown, unit: WarehouseMovementUnit, item: Pick<WarehousePackageQuantity, "piecesPerPackage">): number {
  const enteredQuantity = positiveDecimal(quantity, 0);
  return unit === "package" ? enteredQuantity * getPiecesPerPackage(item) : enteredQuantity;
}

export function formatWarehouseQuantity(totalPieces: unknown, item: Pick<WarehousePackageQuantity, "piecesPerPackage">): string {
  const pieces = Math.max(0, Math.floor(Number(totalPieces) || 0));
  const piecesPerPackage = getPiecesPerPackage(item);
  if (piecesPerPackage <= 1) return `${pieces} قطعة`;
  const packages = Math.floor(pieces / piecesPerPackage);
  const loosePieces = pieces % piecesPerPackage;
  return loosePieces ? `${packages} طرد و ${loosePieces} قطعة` : `${packages} طرد`;
}

export function formatMovementQuantity(movement: { quantity: number; movementUnit?: WarehouseMovementUnit; enteredQuantity?: number }, item?: Pick<WarehousePackageQuantity, "piecesPerPackage">): string {
  const unit = movement.movementUnit;
  if (unit) {
    const entered = positiveDecimal(movement.enteredQuantity, unit === "package" && item ? movement.quantity / getPiecesPerPackage(item) : movement.quantity);
    return `${formatDecimal(entered)} ${unit === "package" ? "طرد" : "قطعة"}`;
  }
  return item ? formatWarehouseQuantity(movement.quantity, item) : `${Math.max(0, Math.floor(movement.quantity || 0))} قطعة`;
}
